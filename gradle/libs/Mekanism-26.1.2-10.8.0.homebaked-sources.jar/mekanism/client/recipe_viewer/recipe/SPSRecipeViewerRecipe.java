package mekanism.client.recipe_viewer.recipe;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Collections;
import java.util.List;
import mekanism.api.SerializationConstants;
import mekanism.api.chemical.ChemicalStackTemplate;
import mekanism.api.recipes.ingredients.ChemicalStackIngredient;
import mekanism.api.recipes.ingredients.creator.IngredientCreatorAccess;
import mekanism.client.recipe_viewer.INamedRVRecipe;
import mekanism.common.Mekanism;
import mekanism.common.config.MekanismConfig;
import mekanism.common.registries.MekanismChemicals;
import mekanism.common.util.RegistryUtils;
import net.minecraft.resources.Identifier;

//TODO - V11: Make the SPS have a proper recipe type to allow for custom recipes
public record SPSRecipeViewerRecipe(Identifier id, ChemicalStackIngredient input, ChemicalStackTemplate output) implements INamedRVRecipe {

    public static final Codec<SPSRecipeViewerRecipe> CODEC = RecordCodecBuilder.create(instance -> instance.group(
          Identifier.CODEC.fieldOf(SerializationConstants.ID).forGetter(SPSRecipeViewerRecipe::id),
          ChemicalStackIngredient.CODEC.fieldOf(SerializationConstants.INPUT).forGetter(SPSRecipeViewerRecipe::input),
          ChemicalStackTemplate.CODEC.fieldOf(SerializationConstants.OUTPUT).forGetter(SPSRecipeViewerRecipe::output)
    ).apply(instance, SPSRecipeViewerRecipe::new));

    public static List<SPSRecipeViewerRecipe> getSPSRecipes() {
        return Collections.singletonList(new SPSRecipeViewerRecipe(
              RegistryUtils.synthetic(Mekanism.rl("antimatter"), "sps"),
              IngredientCreatorAccess.chemicalStack().fromHolder(MekanismChemicals.POLONIUM, MekanismConfig.general.spsInputPerAntimatter.get()),
              MekanismChemicals.ANTIMATTER.asTemplate(1)
        ));
    }
}