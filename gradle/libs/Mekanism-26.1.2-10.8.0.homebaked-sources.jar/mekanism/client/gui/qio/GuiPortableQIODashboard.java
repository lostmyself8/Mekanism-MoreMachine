package mekanism.client.gui.qio;

import mekanism.client.gui.element.tab.GuiQIOFrequencyTab.GuiQIOFrequencyItemTab;
import mekanism.common.component.FrequencyAware;
import mekanism.common.inventory.container.item.PortableQIODashboardContainer;
import mekanism.common.lib.frequency.Frequency.FrequencyIdentity;
import mekanism.common.registries.MekanismDataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.neoforged.neoforge.transfer.item.ItemResource;
import org.jspecify.annotations.Nullable;

public class GuiPortableQIODashboard extends GuiQIOItemViewer<PortableQIODashboardContainer> {

    public GuiPortableQIODashboard(PortableQIODashboardContainer container, Inventory inv, Component title) {
        super(container, inv, title);
    }

    @Override
    protected void addGuiElements() {
        super.addGuiElements();
        addRenderableWidget(new GuiQIOFrequencyItemTab(this, menu.getHand()));
    }

    @Override
    public GuiQIOItemViewer<PortableQIODashboardContainer> recreate(PortableQIODashboardContainer container) {
        return new GuiPortableQIODashboard(container, inv, title);
    }

    @Nullable
    @Override
    public FrequencyIdentity getFrequency() {
        ItemResource itemType = menu.getItemType();
        if (itemType.isEmpty()) {//Note: This shouldn't be empty, but we validate it just in case
            return null;
        }
        return itemType.getOrDefault(MekanismDataComponents.QIO_FREQUENCY, FrequencyAware.none()).identity().orElse(null);
    }
}
